package com.hexaware.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.hexaware.exception.UserNotFoundException;
import com.hexaware.exception.OrderNotFoundException;
import com.hexaware.exception.ProductNotFoundException;

import com.hexaware.entity.Product;
import com.hexaware.entity.User;
import com.hexaware.util.DBUtil;

public class OrderProcessor implements IOrderManagementRepository {

    private Connection conn = DBUtil.getDBConn();

    public void createUser(User user) throws SQLException {
        String checkSql = "SELECT userId FROM users WHERE userId = ?";
        try (PreparedStatement check = conn.prepareStatement(checkSql)) {
            check.setInt(1, user.getUserId());
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
                System.out.println("User with ID " + user.getUserId() + " already exists.");
                return;
            }
        }

        String insertSql = "INSERT INTO users (userId, username, password, role) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(insertSql)) {
            ps.setInt(1, user.getUserId());
            ps.setString(2, user.getUsername());
            ps.setString(3, user.getPassword());
            ps.setString(4, user.getRole());
            ps.executeUpdate();
            System.out.println("User created successfully.");
        }
    }

    public void createProduct(User user, Product product) throws Exception {
        if (!"Admin".equalsIgnoreCase(user.getRole())) {
            throw new Exception("Only Admin users can add products.");
        }

        String checkSql = "SELECT productid FROM product WHERE productid = ?";
        try (PreparedStatement check = conn.prepareStatement(checkSql)) {
            check.setInt(1, product.getProductId());
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
                System.out.println("Product with ID " + product.getProductId() + " already exists.");
                return;
            }
        }

        String sql = "INSERT INTO product (productid, productName, description, price, quantityinStock, type) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, product.getProductId());
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getDescription());
            ps.setDouble(4, product.getPrice());
            ps.setInt(5, product.getQuantityInStock());
            ps.setString(6, product.getType());
            ps.executeUpdate();
            System.out.println("Product added successfully.");
        }
    }

    public void createOrder(User user, List<Product> products) throws SQLException, UserNotFoundException, ProductNotFoundException {
        String checkUser = "SELECT userId FROM users WHERE userId = ?";
        try (PreparedStatement ps = conn.prepareStatement(checkUser)) {
            ps.setInt(1, user.getUserId());
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                throw new UserNotFoundException("User ID " + user.getUserId() + " not found.");
            }
        }

        for (Product p : products) {
            String checkProduct = "SELECT productid FROM product WHERE productid = ?";
            try (PreparedStatement ps = conn.prepareStatement(checkProduct)) {
                ps.setInt(1, p.getProductId());
                ResultSet rs = ps.executeQuery();
                if (!rs.next()) {
                    throw new ProductNotFoundException("Product ID " + p.getProductId() + " not found.");
                }
            }
        }

        String sql = "INSERT INTO orders (userId, productId) VALUES (?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (Product p : products) {
                ps.setInt(1, user.getUserId());
                ps.setInt(2, p.getProductId());
                ps.addBatch();
            }
            ps.executeBatch();
            System.out.println("Order created successfully for user ID " + user.getUserId());
        }
    }

    public void cancelOrder(int userId, int orderId) throws SQLException, OrderNotFoundException {
        String checkSql = "SELECT * FROM orders WHERE orderId = ? AND userId = ?";
        try (PreparedStatement ps = conn.prepareStatement(checkSql)) {
            ps.setInt(1, orderId);
            ps.setInt(2, userId);
            ResultSet rs = ps.executeQuery();
            if (!rs.next()) {
                throw new OrderNotFoundException("Order ID " + orderId + " not found for user ID " + userId);
            }
        }

        String deleteSql = "DELETE FROM orders WHERE orderId = ? AND userId = ?";
        try (PreparedStatement ps = conn.prepareStatement(deleteSql)) {
            ps.setInt(1, orderId);
            ps.setInt(2, userId);
            ps.executeUpdate();
            System.out.println("Order canceled successfully.");
        }
    }

    public List<Product> getAllProducts() throws SQLException {
        List<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM product";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Product p = new Product(
                    rs.getInt("productid"),
                    rs.getString("productName"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("quantityinStock"),
                    rs.getString("type")
                );
                list.add(p);
            }
        }
        return list;
    }

    @Override
    public List<Product> getOrderByUser(User user) throws SQLException, UserNotFoundException {
        List<Product> list = new ArrayList<>();
        
        
        String checkUser = "SELECT * FROM users WHERE userId = ?";
        try (PreparedStatement check = conn.prepareStatement(checkUser)) {
            check.setInt(1, user.getUserId());
            ResultSet rs = check.executeQuery();
            if (!rs.next()) {
                throw new UserNotFoundException("User ID " + user.getUserId() + " not found.");
            }
        }

        
        String sql = "SELECT p.* FROM product p JOIN orders o ON p.productid = o.productid WHERE o.userId = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, user.getUserId());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product p = new Product(
                    rs.getInt("productid"),
                    rs.getString("productName"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("quantityinStock"),
                    rs.getString("type")
                );
                list.add(p);
            }
        }
        return list;
    }
}


