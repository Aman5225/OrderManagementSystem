package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getDBConn() {
        try {
            String url = DBPropertyUtil.getProperty("db.url");// i have referenced the url,user and password  in db.properties
            String user = DBPropertyUtil.getProperty("db.user");
            String password = DBPropertyUtil.getProperty("db.password");

            System.out.println("Connecting to DB → " + url);
            
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

