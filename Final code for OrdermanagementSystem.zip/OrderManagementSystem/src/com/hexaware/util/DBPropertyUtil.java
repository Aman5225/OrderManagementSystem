package com.hexaware.util;

import java.io.FileInputStream;
import java.util.Properties;

public class DBPropertyUtil {

    public static String getProperty(String key) {
        try (FileInputStream fis = new FileInputStream("db.properties")) {
            Properties props = new Properties();
            props.load(fis);
            return props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
