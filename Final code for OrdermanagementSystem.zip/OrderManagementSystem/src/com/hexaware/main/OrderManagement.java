package com.hexaware.main;

import com.hexaware.dao.OrderProcessor;
import com.hexaware.entity.*;
import java.util.*;
import com.hexaware.exception.*;

public class OrderManagement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        OrderProcessor op = new OrderProcessor();

        while (true) {
            System.out.println("\n- Order Management Menu -");
            System.out.println("1. Create User");
            System.out.println("2. Create Product");
            System.out.println("3. Create Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Get All Products");
            System.out.println("6. Get Orders by User");
            System.out.println("7. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter userId: ");
                        int userId = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter username: ");
                        String uname = sc.nextLine();
                        System.out.print("Enter password: ");
                        String pass = sc.nextLine();
                        System.out.print("Enter role (Admin/User): ");
                        String role = sc.nextLine();
                        User u = new User(userId, uname, pass, role);
                        op.createUser(u);
                        break;

                    case 2:
                        System.out.print("Enter Admin userId: ");
                        int aId = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter product type (Clothing/Electronics): ");
                        String type = sc.nextLine();

                        System.out.print("Enter productId: ");
                        int pid = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter product name: ");
                        String pname = sc.nextLine();
                        System.out.print("Enter description: ");
                        String desc = sc.nextLine();
                        System.out.print("Enter price: ");
                        double price = sc.nextDouble();
                        System.out.print("Enter quantity: ");
                        int qty = sc.nextInt(); sc.nextLine();

                        Product p = null;
                        if (type.equalsIgnoreCase("Electronics")) {
                            System.out.print("Enter brand: ");
                            String brand = sc.nextLine();
                            System.out.print("Enter warranty (months): ");
                            int wp = sc.nextInt();
                            p = new Electronics(pid, pname, desc, price, qty, brand, wp);
                        } else {
                            System.out.print("Enter size: ");
                            String size = sc.nextLine();
                            System.out.print("Enter color: ");
                            String color = sc.nextLine();
                            p = new Clothing(pid, pname, desc, price, qty, size, color);
                        }
                        op.createProduct(new User(aId, "", "", "Admin"), p);
                        break;

                    case 3:
                        System.out.print("Enter userId for order: ");
                        int ouid = sc.nextInt(); sc.nextLine();
                        List<Product> prodList = new ArrayList<>();
                        System.out.print("How many products to order? ");
                        int count = sc.nextInt(); sc.nextLine();
                        for (int i = 0; i < count; i++) {
                            System.out.print("Enter productId: ");
                            int opid = sc.nextInt(); sc.nextLine();
                            prodList.add(new Product(opid, "", "", 0, 0, ""));
                        }
                        op.createOrder(new User(ouid, "", "", ""), prodList);
                        break;

                    case 4:
                        System.out.print("Enter userId: ");
                        int cid = sc.nextInt();
                        System.out.print("Enter orderId: ");
                        int oid = sc.nextInt();
                        op.cancelOrder(cid, oid);
                        break;

                    case 5:
                        List<Product> products = op.getAllProducts();
                        if (products.isEmpty()) {
                            System.out.println("No products found in the database.");
                        } else {
                            System.out.println("\nAvailable Products:");
                            for (Product p1 : products) {
                                System.out.println("ID: " + p1.getProductId());
                                System.out.println("Name: " + p1.getProductName());
                                System.out.println("Type: " + p1.getType());
                                System.out.println("Description: " + p1.getDescription());
                                System.out.println("Price: ₹" + p1.getPrice());
                                System.out.println("Stock: " + p1.getQuantityInStock());
                                System.out.println("---------------------------");
                            }
                        }
                        break;

                    case 6:
                        System.out.print("Enter userId: ");
                        int uid = sc.nextInt();
                        User user = new User(uid, "", "", "");  // Dummy User object with only userId

                        List<Product> userOrders = op.getOrderByUser(user);

                        if (userOrders.isEmpty()) {
                            System.out.println("No orders found for user ID " + uid);
                        } else {
                            System.out.println("Products ordered by user " + uid + ":");
                            userOrders.forEach(prod -> System.out.println(prod.getProductName()));
                        }
                        break;


                    case 7:
                        System.out.println("Exiting...");
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
            }
        }
    }
}



